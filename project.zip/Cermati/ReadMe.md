How to Execiute The suite

1. Import as maven project in eclipse
2. Run Maven Install
3. Reun the main function utils/Runner.java 