package automationscript;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pagobjects.ebay_homepage;
import pagobjects.ebay_searchpage;
import utils.Action;
import utils.PropertyfileConfig;

public class test_ebay_functions extends Action {

	static ebay_homepage oHome = new ebay_homepage();
	static ebay_searchpage oSearch = new ebay_searchpage();

	@Test
	public static void Access_Product_with_filters() throws InterruptedException, IOException {

		System.out.println("Create_Escalation_WithAllFields Verification Started !");
		SoftAssert sAssert = new SoftAssert();
		try {

			Click(oHome.getHome_lkShopByCategory());
			
			WebDriverWait wait = new WebDriverWait(driver,30);
			waitForElementVisible1(oHome.getHome_lkShopByCategory_CellPhoneAccesrories());
			Click(oHome.getHome_lkShopByCategory_CellPhoneAccesrories());
			waitForElementVisible1(oSearch.getSearchPage_lkPhoneSmartphones());
			wait.until(ExpectedConditions.elementToBeClickable(oSearch.getSearchPage_lkPhoneSmartphones()));
			
			Click(oSearch.getSearchPage_lkPhoneSmartphones());
			PageScrollDown(400);
			Click(oSearch.getSearchPage_AllFilters());
			Click(oSearch.getSearchPage_FilterScreenSize());

			Click(oSearch.getSearchPage_FilterScreenSizecheckbox());
			Click(oSearch.getSearchPage_FilterPrice());

			type(oSearch.getSearchPage_FilterPriceInput(), "5,000");
			Click(oSearch.getSearchPage_ItemLocation());
			Click(oSearch.getSearchPage_ItemLocationInput());
			Click(oSearch.getSearchPage_btnApply());
			JavascriptExecutor j = (JavascriptExecutor) driver;
			j.executeScript("return document.readyState").toString().equals("complete");

			String scrnsize = PropertyfileConfig.getStringValueFromProperty("size");
			String price = PropertyfileConfig.getStringValueFromProperty("price");
			String itemLocation = PropertyfileConfig.getStringValueFromProperty("textsearch");

			String fltrText = getObjectText(oSearch.getSearchPage_Filteredtxt());
			boolean b = false;
			System.out.println(fltrText);

			if (fltrText.contains(price) && fltrText.contains(scrnsize)) {
				b = true;

			}

			sAssert.assertEquals(b, true, "text is not matching with the filter");

			sAssert.assertAll();
		}

		catch (Exception ex) {
			ex.printStackTrace();
			sAssert.assertFalse(true, "exception occured while verifying Access_Product_with_filters !");
			sAssert.assertAll();
		}

	}

	@Test
	public static void Access_Product_Search() throws InterruptedException, IOException {
		System.out.println("Access_Product_Search Verification Started !");
		SoftAssert sAssert = new SoftAssert();
		try {

			String inputSearchtxt = PropertyfileConfig.getStringValueFromProperty("textsearch");
			String catDropdown = PropertyfileConfig.getStringValueFromProperty("catdd");
			System.out.println("catdropdown : " + catDropdown);

			type(oHome.getHome_txtSearchBox(), inputSearchtxt);
			dropdown(oHome.getHome_ddCategory(), catDropdown);
			Click(oHome.getHome_btnSearchBox());
			JavascriptExecutor j = (JavascriptExecutor) driver;
			j.executeScript("return document.readyState").toString().equals("complete");

			List<WebElement> ls = driver.findElements(oSearch.getSearchPage_AllSearchprooducts());
			String titleFirstElement = ls.get(0).getText();
			System.out.println("titleFirstElement : " + titleFirstElement);
			boolean b = false;
			if (titleFirstElement.toLowerCase().contains(inputSearchtxt.toLowerCase())) {
				b = true;

			}

			sAssert.assertEquals(b, true, "text is not matching with the title of product");
			sAssert.assertAll();
		}

		catch (Exception ex) {
			sAssert.assertFalse(true, "exception occured while verifying Access_Product_Search !");
			sAssert.assertAll();
		}

	}
}
