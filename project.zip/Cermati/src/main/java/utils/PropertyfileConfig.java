package utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyfileConfig {
	static String propFileName = "datafiles/config.properties";
	private final static Properties prop = new Properties();
	static InputStream ip = null;
	static int value = 0;

	public static String getStringValueFromProperty(String key) throws FileNotFoundException {

		try {
			ip = new FileInputStream(propFileName);
			if (ip != null) {
				prop.load(ip);
			}
		} catch (Exception ex) {
			throw new FileNotFoundException("property file '" + propFileName + "' not found");
		}
		String strvalue = prop.getProperty(key);

		return strvalue;

	}

	public static int getintValueFromProperty(String key) throws FileNotFoundException 
	{ 
		try {
			ip = new FileInputStream(propFileName);
			if (ip != null) {
				prop.load(ip);
			}
		} catch (Exception ex ) {
			throw new FileNotFoundException("property file" + propFileName + "not found");
		}
		String strvalue = prop.getProperty(key);
		 value = Integer.parseInt(strvalue);		
		return value;

	}

}
