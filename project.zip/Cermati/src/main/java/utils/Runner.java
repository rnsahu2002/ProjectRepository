package utils;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;
import org.testng.TestNG;
import org.testng.collections.Lists;

public class Runner {
	public static void main(String[] args) throws IOException, InterruptedException {

		try {
		
			Properties props = new Properties();
			PropertyConfigurator.configure(props);
			TestNG testng = new TestNG();
			List<String> suites = Lists.newArrayList();
			suites.add("testng.xml");
			testng.setTestSuites(suites);
			testng.run();
		}

		catch (Exception ex) {
			ex.printStackTrace();

		}

	}

}