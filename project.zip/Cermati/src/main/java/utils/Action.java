package utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.google.common.base.Function;

public class Action extends BrowserConfig {

	public static String parent, child;
	public static int count = 0;

	public void openUrl(String url) {
		driver.get(url);
	}

	public static void type(By locator, String data) // To type data on the specified
	{
		try {

			System.out.println("Entering the data : " + data);
			waitForElementVisible1(locator);

			element(locator).clear();
			Thread.sleep(1000);
			element(locator).sendKeys(data);
			keyBoardEvent(locator, Keys.TAB);
		} catch (Exception ex) {

			ex.printStackTrace();
		}

	}

	public static WebElement element(By locator) // returns Webelement
	{
		try {
			WebElement element;
			element = driver.findElement(locator);
			return element;
		} catch (Exception ex) {

			ex.printStackTrace();
		}

		return null;
	}

	public static void keyBoardEvent(By locator, Keys event) {

		try {
			Thread.sleep(1000);
			element(locator).sendKeys(event);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public static void dropdown(By locator, String text) {
		try {
			Select drop = new Select(element(locator));
			drop.selectByVisibleText(text);
		} catch (NoSuchElementException e) {
			throw e;
		}
	}

	public static void Click(By locator) {
		try {
			waitForElementVisible1(locator);
			driver.findElement(locator).click();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static void PageScrollDown(int pixels) throws InterruptedException {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0," + pixels + ")");
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static void waitForElementVisible1(final By locator) throws FileNotFoundException // Waits for an element to
	// be
	{
		int waitInterval = PropertyfileConfig.getintValueFromProperty("waitforElementInterval");
		int pollingInterval = PropertyfileConfig.getintValueFromProperty("waitforElemenPollingInterval");

		try {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(waitInterval, TimeUnit.SECONDS)
					.pollingEvery(pollingInterval, TimeUnit.SECONDS).ignoring(NoSuchElementException.class)
					.ignoring(NullPointerException.class).ignoring(ElementNotFoundException.class);
			WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
				public WebElement apply(WebDriver driver) {
					return driver.findElement(locator);
				}
			});
		} catch (Exception ex) {

			ex.printStackTrace();
		}

	}

	public static String getObjectText(By locator) throws IOException // Returns text

	{
		try {
			waitForElementVisible1(locator);
			String message = element(locator).getText();
			return message;
		} catch (Exception ex) {
			ex.printStackTrace();

		}
		return "";
	}

}
