package utils;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserConfig {

	protected static WebDriver driver;

	@BeforeMethod(alwaysRun = true)
	public void SetconfigurationBrowser() throws IOException, InterruptedException {
		System.out.println("Before Test");
		try {
			String Browser = PropertyfileConfig.getStringValueFromProperty("Browser").toLowerCase().trim();
			System.out.println("Browser is: " + Browser);

			String ebayurl = PropertyfileConfig.getStringValueFromProperty("ebayurl");
			if (Browser.equalsIgnoreCase("chrome")) {
				System.out.println("chrome is selected");

				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.get(ebayurl);

			}

		} catch (Exception ex) {
			ex.printStackTrace();

		}

	}

	protected static void waitForLoad(WebDriver driver) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 100);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*")));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@AfterMethod
	public void CloseDriver() {

		driver.close();
		System.out.println("chrome browser closed ");

	}

}
