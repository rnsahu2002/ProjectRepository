package pagobjects;

import org.openqa.selenium.By;

public class ebay_searchpage {
	
	
	private By SearchPage_lkPhoneSmartphones = By.xpath("(//*[contains(text(),'Cell Phones & Smartphones')])[1]");	
	private By SearchPage_AllFilters = By.xpath("(//*[contains(text(),'All Filters')])[1]");	
	private By SearchPage_FilterScreenSize = By.xpath("//*[@id='x-overlay__form']/div[1]/div/div/div[7]");
	private By SearchPage_FilterScreenSizecheckbox = By.xpath("(//*[@class=\"checkbox cbx x-refine__multi-select-checkbox \"]/input)[1]");
	
	private By SearchPage_FilterPrice = By.xpath("//*[@id='x-overlay__form']/div[1]/div/div/div[22]");
	private By SearchPage_FilterPriceInput = By.xpath("(//*[@class=\"x-textrange__block\"]/input)[1]");

	private By SearchPage_ItemLocation = By.xpath("//*[@id='x-overlay__form']/div[1]/div/div/div[24]");
	private By SearchPage_ItemLocationInput = By.xpath("(//*[@class=\"radio field__control rbx x-refine__single-select-radio\"]/input)[2]");
	
	
	private By SearchPage_btnApply = By.xpath("//*[@class=\"x-overlay-footer__apply\"]/button");
	
	private By SearchPage_Filteredtxt = By.xpath("/html/body/div[5]/div[2]/h1/span");
	
	private By SearchPage_AllSearchprooducts= By.xpath("//*[@id='srp-river-results']/ul/li/div/div/a/h3");

	public By getSearchPage_AllSearchprooducts() {
		return SearchPage_AllSearchprooducts;
	}
	

	public By getSearchPage_Filteredtxt() {
		return SearchPage_Filteredtxt;
	}
	

	
	public By getSearchPage_btnApply() {
		return SearchPage_btnApply;
	}
	
	public By getSearchPage_lkPhoneSmartphones() {
		return SearchPage_lkPhoneSmartphones;
	}
	public By getSearchPage_AllFilters() {
		return SearchPage_AllFilters;
	}
	public By getSearchPage_FilterScreenSize() {
		return SearchPage_FilterScreenSize;
	}
	public By getSearchPage_FilterScreenSizecheckbox() {
		return SearchPage_FilterScreenSizecheckbox;
	}
	public By getSearchPage_FilterPrice() {
		return SearchPage_FilterPrice;
	}
	public By getSearchPage_FilterPriceInput() {
		return SearchPage_FilterPriceInput;
	}
	public By getSearchPage_ItemLocation() {
		return SearchPage_ItemLocation;
	}
	public By getSearchPage_ItemLocationInput() {
		return SearchPage_ItemLocationInput;
	}

	
	

}
