package pagobjects;

import org.openqa.selenium.By;

public class ebay_homepage {

	private By Home_lkShopByCategory = By.xpath("//*[@id=\"gh-shop-a\"]");
	private By Home_lkShopByCategory_CellPhoneAccesrories = By.xpath("//*[@id=\"gh-sbc\"]/tbody/tr/td[1]/ul[2]/li[4]/a");
	private By Home_txtSearchBox = By.xpath("//*[@id='gh-ac']");
	private By Home_btnSearchBox = By.xpath("//*[@id='gh-btn']");
	private By Home_ddCategory = By.xpath("//*[@id='gh-cat']");
	

	
	//*[@id="x-overlay__form"]/div[1]/div/div/div[7]

	
	
	public By getHome_ddCategory() {
		return Home_ddCategory;
	}	
	
	public By getHome_btnSearchBox() {
		return Home_btnSearchBox;
	}
	public By getHome_lkShopByCategory() {
		return Home_lkShopByCategory;
	}
	public By getHome_lkShopByCategory_CellPhoneAccesrories() {
		return Home_lkShopByCategory_CellPhoneAccesrories;
	}
	public By getHome_txtSearchBox() {
		return Home_txtSearchBox;
	}

	
	


	
}
